/**
 * Main JavaScript file
 */
document.addEventListener('DOMContentLoaded', function() {
    console.log('Theme JS loaded');
    
    // Mobile menu toggle logic can go here
});